Brendan Clare
12/14/24
Advisor: Professor Douglass

These three games are my adaptations of popular browser/mobile games made in Processing. To play yourself press H. To simulate NEAT press N. To simulate genetic press G. To simulate parallel press P. They are built inside genetic algorithm templates credit to: Code-Bullet. (n.d.). GitHub - Code-Bullet/NEAT_Template: This is mainly for me, but if anyone wishes to use it then go ahead. GitHub. https://github.com/Code-Bullet/NEAT_Template 
Code-Bullet.(n.d.).GitHub-Code-Bullet/Smart-Dots-Genetic-Algorithm-Tutorial: Here is the code for my genetic algorithm tutorial. GitHub. https://github.com/Code-Bullet/Smart-Dots-Genetic-Algorithm-Tutorial 
